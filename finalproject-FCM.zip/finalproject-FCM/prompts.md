> Detalla en esta sección los prompts principales utilizados durante la creación del proyecto, que justifiquen el uso de asistentes de código en todas las fases del ciclo de vida del desarrollo. Esperamos un máximo de 3 por sección, principalmente los de creación inicial o los de corrección o adición de funcionalidades que consideres más relevantes.
> Puedes añadir adicionalmente la conversación completa como link o archivo adjunto si así lo consideras

## Índice

1. [Descripción general del producto](#1-descripción-general-del-producto)
2. [Arquitectura del sistema](#2-arquitectura-del-sistema)
3. [Modelo de datos](#3-modelo-de-datos)
4. [Especificación de la API](#4-especificación-de-la-api)
5. [Historias de usuario](#5-historias-de-usuario)
6. [Tickets de trabajo](#6-tickets-de-trabajo)
7. [Pull requests](#7-pull-requests)

---

## 1. Descripción general del producto

## Prompt 1️⃣ ChatGPT: Brainstorming y Naming

- **🤖 ChatGPT-4/5** ([chatgpt.com](https://chatgpt.com/))

**Prompt original:**

```text
"Compadre dame un buen nombre, así perro, para el proyecto que estoy armando de un agente que pueda consultar con lenguaje natural la base de conocimiento, manuales, normativas de la CNBV, disposiciones oficiales, leyes que le aplican al banco donde trabajo, que utiliza bd vectoriales y embedings, que te permita buscar semánticamente y te arroja los resultados pero además te dice en qué página y desde el portal que voy a construir en web, pueda dar click y te lleve al pdf y a la página específica y te lo abra en un barside"
```

---

## Prompt 2️⃣ NotebookLM: Investigación y Redacción de Funcionalidad

**📓 NotebookLM** ([notebooklm.google.com](https://notebooklm.google.com/))

- Se utilizó NotebookLM para analizar tendencias, estudiar productos similares y redactar la funcionalidad básica deseada.

- Se subió como fuente inicial en modo texto plano la siguiente descripción:

```text
LexiMind es un agente conversacional basado en IA diseñado para facilitar el acceso y la consulta de normativas, manuales y leyes aplicables a instituciones financieras, así como manuales técnicos y de operaciones de cada área del banco, desde áreas de TI hasta Operativas como Contabilidad, Compliance.

Utiliza tecnologías avanzadas de procesamiento de lenguaje natural (NLP) y bases de datos vectoriales para ofrecer respuestas precisas y contextuales a las consultas de los usuarios. Además, LexiMind está integrado en un portal web intuitivo que permite a los usuarios buscar información de manera semántica y acceder directamente a documentos PDF específicos, abriendo la página exacta donde se encuentra la información relevante. Funciona como una base de conocimiento dinámica y accesible, mejorando la eficiencia y la toma de decisiones dentro del banco.

Funcionalidades Clave:

- Carga de documentos: Permite la importación masiva de documentos en formatos como PDF, Word, Texto Plano, Markdown, etc.

- Indexación y Vectorización: Utiliza técnicas de embedding para convertir el contenido de los documentos en vectores, facilitando la búsqueda semántica.

- Búsqueda Semántica: Los usuarios pueden realizar consultas en lenguaje natural y recibir respuestas basadas en el contexto y significado, no solo en palabras clave.

- Navegación Directa: Al proporcionar respuestas, el agente incluye enlaces directos a los documentos PDF y la página específica donde se encuentra la información solicitada.

- Historial de consultas: Mantiene un registro de las consultas realizadas para mejorar la precisión y personalización de las respuestas.

- Seguridad y Privacidad: Implementa medidas de seguridad para proteger la información sensible y cumplir con las regulaciones de datos.

- Interfaz de Usuario Intuitiva: Un portal web fácil de usar que permite a los empleados del banco interactuar con el agente sin necesidad de conocimientos técnicos avanzados.

- Te permite manejar pdf's y documentos favoritos, últimos abiertos, y documentos por área o departamento

- Permite puntuar las respuestas para mejorar el modelo con feedback humano
```

### NotebookLM: Descubrimiento de Fuentes y Mejores Prácticas

- Se utilizó la funcionalidad de "Descubrir Fuentes" para analizar tendencias y mejores prácticas en la industria.
- Se pidió al modelo actuar como Product Manager y definir artefactos clave:

**Prompt original:**

```text
Estoy creando internamente en el banco donde trabajo una Plataforma de base de conocimiento que pueda mantener y consultar con lenguaje natural cualquier informacion almacenada, desde manuales de TI hasta Documentos Legales y de Compliance. Todavía no hay nada creado, así que toca ponerse el gorro de product manager y definir esas funcionalidades clave que harán brillar el proyecto al que denominaremos "LexiMind" es el momento de hacer brainstorming, investigar cuáles pueden ser las claves del éxito, y dejarlo plasmado para el resto del equipo.

Tu misión es diseñar la primera versión del sistema, entregando los siguientes artefactos:

1 Descripción breve del proyecto:
2 Objetivo
3 Características y funcionalidades principales
```

---

## 2. Arquitectura del Sistema

### **2.1. Diagrama de arquitectura:**

**Prompt 1:**

**Prompt 2:**

**Prompt 3:**

### **2.2. Descripción de componentes principales:**

**Prompt 1:**

**Prompt 2:**

**Prompt 3:**

### **2.3. Descripción de alto nivel del proyecto y estructura de ficheros**

**Prompt 1:**

- **🤖 Cursor** Modo Agente

Sobre un cascaron o estructura de proyecto backend en NodeJS donde había estado creando las bases del proyecto, le solicite al IDE de Cursor que me generara una descripción de alto nivel del proyecto y la estructura de ficheros.

**Prompt original:**

```text
En base al proyecto actual, sus carpetas y archivos, dime que patron de diseño de sistema utiliza, por ejemplo si es SOLID, Arquietctura Hexogonal, etc
```

**Prompt 2:**

Le solicite a Cursor que me generara la respuesta anterior en formato markdown.

```text
En el archivo patron_disenio.md, agregar la ultima respuesta en formato markdown, con iconos, emojis, listas, encabezados y todo lo que consideres necesario
```

**Prompt 3:**

### **2.4. Infraestructura y despliegue**

```text
En esta sección, describe la infraestructura necesaria para desplegar el sistema, incluyendo servidores, bases de datos, y cualquier otro componente relevante.
**Prompt 1:**

**Prompt 2:**

**Prompt 3:**

### **2.5. Seguridad**

**Prompt 1:**

**Prompt 2:**

**Prompt 3:**

### **2.6. Tests**

**Prompt 1:**

**Prompt 2:**

**Prompt 3:**

---

### 3. Modelo de Datos

**Prompt 1:**

**Prompt 2:**

**Prompt 3:**

---

### 4. Especificación de la API

**Prompt 1:**

**Prompt 2:**

**Prompt 3:**

---

### 5. Historias de Usuario

**Prompt 1:**

**Prompt 2:**

**Prompt 3:**

---

### 6. Tickets de Trabajo

**Prompt 1:**

**Prompt 2:**

**Prompt 3:**

---

### 7. Pull Requests

**Prompt 1:**

**Prompt 2:**

**Prompt 3:**
```
