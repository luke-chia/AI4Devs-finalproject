## Índice

0. [Ficha del proyecto](#0-ficha-del-proyecto)
1. [Descripción general del producto](#1-descripción-general-del-producto)
2. [Arquitectura del sistema](#2-arquitectura-del-sistema)
3. [Modelo de datos](#3-modelo-de-datos)
4. [Especificación de la API](#4-especificación-de-la-api)
5. [Historias de usuario](#5-historias-de-usuario)
6. [Tickets de trabajo](#6-tickets-de-trabajo)
7. [Pull requests](#7-pull-requests)

---

## 0. Ficha del proyecto

### **0.1. Alumno:** Francisco Javier Chía Moctezuma

### **0.2. Nombre del proyecto:** LexiMind

### **0.3. Descripción breve del proyecto:**

### **0.4. URL del proyecto:**

> Puede ser pública o privada, en cuyo caso deberás compartir los accesos de manera segura. Puedes enviarlos a [alvaro@lidr.co](mailto:alvaro@lidr.co) usando algún servicio como [onetimesecret](https://onetimesecret.com/).

### 0.5. URL o archivo comprimido del repositorio

> Puedes tenerlo alojado en público o en privado, en cuyo caso deberás compartir los accesos de manera segura. Puedes enviarlos a [alvaro@lidr.co](mailto:alvaro@lidr.co) usando algún servicio como [onetimesecret](https://onetimesecret.com/). También puedes compartir por correo un archivo zip con el contenido

---

## 1. Descripción general del producto

> Con estas funcionalidades, LexiMind no solo será un repositorio, sino un asistente inteligente que empodere a los empleados del banco al transformar la forma en que acceden y utilizan el conocimiento.

> LexiMind es un agente conversacional basado en Inteligencia Artificial (IA), diseñado específicamente para centralizar, organizar y facilitar el acceso a toda la documentación interna del banco. No solo será un repositorio, sino un asistente inteligente que empodere a los empleados al transformar la forma en que acceden y utilizan el conocimiento.

### **1.1. Objetivo:**

El objetivo principal de LexiMind es incrementar la eficiencia y la toma de decisiones dentro del banco. Al proporcionar a los empleados un acceso rápido y preciso a la información relevante, LexiMind busca:

- **Optimizar la productividad de los empleados:**

  - Reducir significativamente el tiempo dedicado a buscar información en diversos sistemas y documentos.
  - Permitir que los empleados se concentren en tareas de mayor valor.

- **Mejorar la precisión y consistencia de las respuestas:**

  - Asegurar acceso a información verificada y actualizada para todos los empleados.
  - Evitar la desinformación, especialmente en áreas críticas como legal y compliance.

- **Agilizar la incorporación y capacitación de nuevos empleados:**

  - Proporcionar una guía exhaustiva y accesible para nuevos colaboradores.
  - Facilitar la familiarización rápida con políticas, procedimientos y productos del banco.
  - Reducir la necesidad de extensas sesiones de formación.

- **Fomentar la innovación y la toma de decisiones informadas:**

  - Democratizar el acceso al conocimiento.
  - Empoderar a los equipos para identificar tendencias, anticipar problemas y tomar decisiones estratégicas basadas en datos precisos y actualizados.

- **Reducir los costos operativos:**

  - Automatizar consultas repetitivas.
  - Mejorar la eficiencia en la búsqueda de información.
  - Liberar recursos humanos y disminuir los costos asociados con la gestión manual del conocimiento.

- **Asegurar el cumplimiento normativo:**
  - Facilitar el acceso a normativas, leyes y políticas internas.
  - Ayudar a los empleados a mantenerse informados sobre los requisitos regulatorios.
  - Reducir riesgos legales.

En esencia, LexiMind busca transformar al banco en un centro de conocimiento inteligente.

### **1.2. Características y funcionalidades principales:**

La primera versión de LexiMind se centrará en las siguientes características y funcionalidades clave:

- 📄 **Carga y Gestión de Documentos:**

  - Importación masiva de documentos en formatos como PDF, Word, Texto Plano, Markdown, etc.
  - Actualización continua del contenido y adición de nuevos documentos.
  - Auditoría de contenido para identificar información relevante, desactualizada o que debe eliminarse.
  - Estructuración y categorización mediante categorías, etiquetas y palabras clave.

- 🧬 **Indexación y Vectorización Inteligente:**

  - Técnicas de embedding para convertir el contenido en vectores mediante IA.
  - Reconocimiento de intenciones para entender el contexto de la consulta del usuario.

- 🔎 **Búsqueda y Recuperación Avanzada:**

  - Búsqueda semántica en lenguaje natural, basada en contexto y significado.
  - Navegación directa a documentos y páginas específicas mediante enlaces.
  - Generación Aumentada por Recuperación (RAG) para respuestas fundamentadas en información interna, minimizando "alucinaciones".

- 💬 **Interacción Conversacional y Experiencia de Usuario:**

  - Interfaz web intuitiva y fácil de usar para empleados sin conocimientos técnicos.
  - Respuestas en lenguaje natural, adaptadas al tono profesional y servicial.
  - Historial de consultas para mejorar precisión y personalización.
  - Gestión de documentos favoritos, últimos abiertos y por área/departamento.
  - Personalización del tono y personalidad del asistente.

- 🔒 **Seguridad y Privacidad de Datos:**

  - Medidas de seguridad robustas y cumplimiento de regulaciones financieras.
  - Control de acceso basado en roles (RBAC).
  - Auditorías de seguridad periódicas.

- 📈 **Mejora Continua y Analítica:**
  - Sistema de retroalimentación para puntuar respuestas y mejorar el modelo.
  - Monitoreo y análisis de uso para identificar áreas de mejora y valor entregado.

### **1.3. Diseño y experiencia de usuario:**

> Proporciona imágenes y/o videotutorial mostrando la experiencia del usuario desde que aterriza en la aplicación, pasando por todas las funcionalidades principales.

### **1.4. Instrucciones de instalación:**

> Documenta de manera precisa las instrucciones para instalar y poner en marcha el proyecto en local (librerías, backend, frontend, servidor, base de datos, migraciones y semillas de datos, etc.)

---

## 2. Arquitectura del Sistema

### **2.1. Diagrama de arquitectura:**

> Usa el formato que consideres más adecuado para representar los componentes principales de la aplicación y las tecnologías utilizadas. Explica si sigue algún patrón predefinido, justifica por qué se ha elegido esta arquitectura, y destaca los beneficios principales que aportan al proyecto y justifican su uso, así como sacrificios o déficits que implica.

### **2.2. Descripción de componentes principales:**

> Describe los componentes más importantes, incluyendo la tecnología utilizada

### **2.3. Descripción de alto nivel del proyecto y estructura de ficheros**

## 🏗️ Patrones de Diseño del Proyecto Backend

Este proyecto implementa una **Arquitectura Hexagonal (Ports and Adapters)** combinada con principios **SOLID**, siguiendo las mejores prácticas de **Clean Architecture**.

---

## 🎯 Patrón Principal: Arquitectura Hexagonal

### 🔍 ¿Qué es la Arquitectura Hexagonal?

La Arquitectura Hexagonal, también conocida como **Ports and Adapters**, es un patrón arquitectónico que:

- 🎯 **Aísla la lógica de negocio** del mundo exterior
- 🔌 **Usa puertos (interfaces)** para definir contratos
- 🔧 **Implementa adaptadores** para conectar con sistemas externos
- 🛡️ **Protege el dominio** de cambios en infraestructura

---

## 🏛️ Estructura de Capas y Carpetas

### 1. 🧠 Domain Layer (`src/domain/`)

> **Propósito**: Contiene la lógica de negocio pura, independiente de cualquier tecnología externa.

#### 📁 Componentes:

- **🏷️ Entities**:

  - `UserEntity` - Objetos de dominio puros
  - Representan conceptos del negocio

- **🔌 Repositories**:

  - `AuthRepository` (abstract) - Puertos/Interfaces
  - Define contratos para acceso a datos

- **📡 Datasources**:

  - `AuthDatasource` (abstract) - Puertos/Interfaces
  - Abstrae fuentes de datos externas

- **📦 DTOs**:

  - `RegisterUserDto` - Objetos de transferencia de datos
  - Validación y estructura de entrada

- **⚠️ Errors**:
  - `CustomError` - Errores específicos del dominio
  - Manejo centralizado de excepciones

### 2. 🔧 Infrastructure Layer (`src/infrastructure/`)

> **Propósito**: Implementa los adaptadores que conectan el dominio con sistemas externos.

#### 📁 Componentes:

- **🗄️ Repositories**:

  - `AuthRepositoryImpl` - Adaptadores que implementan los puertos
  - Conecta lógica de negocio con fuentes de datos

- **📊 Datasources**:

  - `AuthDatasourceImpl` - Adaptadores para fuentes de datos
  - Implementaciones específicas de acceso a datos

- **🔄 Mappers**:
  - Transforman datos entre capas
  - Mantienen separación de responsabilidades

### 3. 🎨 Presentation Layer (`src/presentation/`)

> **Propósito**: Maneja la interfaz de usuario y comunicación externa.

#### 📁 Componentes:

- **🎮 Controllers**:

  - `AuthController` - Adaptadores para HTTP
  - Manejan requests/responses

- **🛣️ Routes**:

  - `AppRoutes`, `AuthRoutes` - Configuración de rutas
  - Define endpoints de la API

- **🖥️ Server**:
  - Configuración del servidor Express
  - Middleware y configuración general

### 4. 💾 Data Layer (`src/data/`)

> **Propósito**: Implementaciones específicas de persistencia de datos.

#### 📁 Componentes:

- **🍃 MongoDB**: Implementación para base de datos NoSQL
- **🐘 PostgreSQL**: Implementación para base de datos relacional

---

## ⚡ Principios SOLID Aplicados

### 🔄 Dependency Inversion Principle (DIP)

```typescript
// ✅ Los controladores dependen de abstracciones
constructor(
    private readonly authRepository: AuthRepository  // Interface, no implementación
) {}
```

### 🎯 Single Responsibility Principle (SRP)

- **AuthController**: Solo maneja requests HTTP
- **AuthRepository**: Solo define contratos de acceso a datos
- **UserEntity**: Solo representa un usuario del dominio

### 🔓 Open/Closed Principle (OCP)

- ✅ Fácil extensión mediante nuevas implementaciones
- ✅ Nuevos datasources sin modificar código existente

### 🔗 Interface Segregation Principle (ISP)

- ✅ Interfaces específicas y cohesivas
- ✅ No hay dependencias innecesarias

### 🔄 Liskov Substitution Principle (LSP)

- ✅ Cualquier implementación puede sustituir a su abstracción

---

## 🌟 Características Hexagonales

### 🔌 Puertos (Ports)

```typescript
// Interface que define el contrato
export abstract class AuthRepository {
  abstract registerUser(registerUserDto: RegisterUserDto): Promise<UserEntity>
}
```

### 🔧 Adaptadores (Adapters)

```typescript
// Implementación concreta del puerto
export class AuthRepositoryImpl implements AuthRepository {
  constructor(private readonly authDatasource: AuthDatasource) {}

  registerUser(registerUserDto: RegisterUserDto): Promise<UserEntity> {
    return this.authDatasource.registerUser(registerUserDto)
  }
}
```

### 🔄 Inversión de Dependencias

- 🎯 **El dominio NO depende** de infraestructura
- 🔌 **La infraestructura SÍ depende** del dominio
- 🛡️ **Protección** contra cambios externos

### 🎨 Separación de Responsabilidades

- 🧠 **Domain**: Lógica de negocio pura
- 🔧 **Infrastructure**: Implementaciones técnicas
- 🎨 **Presentation**: Interfaz de usuario
- 💾 **Data**: Persistencia específica

---

## 🚀 Beneficios de esta Arquitectura

### ✅ Ventajas

- 🛡️ **Testabilidad**: Fácil testing con mocks
- 🔄 **Flexibilidad**: Cambios sin afectar el dominio
- 🎯 **Mantenibilidad**: Código organizado y claro
- 🔌 **Extensibilidad**: Nuevas funcionalidades sin romper existentes
- 🧪 **Independencia**: Tecnologías intercambiables

### 📊 Métricas de Calidad

- 🎯 **Alto Cohesion**: Cada clase tiene una responsabilidad clara
- 🔗 **Bajo Acoplamiento**: Dependencias mínimas entre capas
- 🧪 **Testabilidad**: 100% de cobertura posible
- 🔄 **Reutilización**: Componentes independientes

---

### **2.4. Infraestructura y despliegue**

> Detalla la infraestructura del proyecto, incluyendo un diagrama en el formato que creas conveniente, y explica el proceso de despliegue que se sigue

### **2.5. Seguridad**

> Enumera y describe las prácticas de seguridad principales que se han implementado en el proyecto, añadiendo ejemplos si procede

### **2.6. Tests**

> Describe brevemente algunos de los tests realizados

---

## 3. Modelo de Datos

### **3.1. Diagrama del modelo de datos:**

> Recomendamos usar mermaid para el modelo de datos, y utilizar todos los parámetros que permite la sintaxis para dar el máximo detalle, por ejemplo las claves primarias y foráneas.

### **3.2. Descripción de entidades principales:**

> Recuerda incluir el máximo detalle de cada entidad, como el nombre y tipo de cada atributo, descripción breve si procede, claves primarias y foráneas, relaciones y tipo de relación, restricciones (unique, not null…), etc.

---

## 4. Especificación de la API

> Si tu backend se comunica a través de API, describe los endpoints principales (máximo 3) en formato OpenAPI. Opcionalmente puedes añadir un ejemplo de petición y de respuesta para mayor claridad

---

## 5. Historias de Usuario

> Documenta 3 de las historias de usuario principales utilizadas durante el desarrollo, teniendo en cuenta las buenas prácticas de producto al respecto.

**Historia de Usuario 1**

**Historia de Usuario 2**

**Historia de Usuario 3**

---

## 6. Tickets de Trabajo

> Documenta 3 de los tickets de trabajo principales del desarrollo, uno de backend, uno de frontend, y uno de bases de datos. Da todo el detalle requerido para desarrollar la tarea de inicio a fin teniendo en cuenta las buenas prácticas al respecto.

**Ticket 1**

**Ticket 2**

**Ticket 3**

---

## 7. Pull Requests

> Documenta 3 de las Pull Requests realizadas durante la ejecución del proyecto

**Pull Request 1**

**Pull Request 2**

**Pull Request 3**
